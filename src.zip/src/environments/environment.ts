
export const environment = {
    production: false,
  firebase: {
  apiKey: "AIzaSyCyiCGvrhQBgJkCpeHdn_wP03_pBzAfPRo",
  authDomain: "appfit-f2932.firebaseapp.com",
  projectId: "appfit-f2932",
  storageBucket: "appfit-f2932.firebasestorage.app",
  messagingSenderId: "268383674521",
  appId: "1:268383674521:web:374d5c86996fa70a4dd808",
  measurementId: "G-DDJB7WYW36"
  }
};
